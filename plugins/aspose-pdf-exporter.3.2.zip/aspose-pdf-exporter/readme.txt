﻿=== Aspose.PDF Exporter ===
Contributors: asposemarketplace
Contributor's website: https://www.aspose.cloud/
Tags: wordpress PDF export,wordpress to PDF, wordpress post content to PDF, cloud PDF exporter, post to PDF, wordpress post to PDF
Requires at least: 5.0
Tested up to: 5.9
Stable tag: 3.2
License: GPLv2 or later

Aspose.PDF Exporter exports posts into a PDF file. This plugin converts/exports/stores single or many posts/pages to a single PDF file.

== Description ==
Aspose.PDF Exporter Plugin for WordPress allows administrators to export posts/pages to PDF document. This module demonstrates powerful Export feature of [Aspose.PDF Cloud](https://products.aspose.cloud/pdf/family). It adds a simple bulk action in the drop down "Export to PDF(Aspose.PDF Exporter)" and as soon as the bulk action is called, it exports all posts to a PDF document.

== Installation ==


Please follow the instructions in this [post](https://docs.aspose.cloud/display/pdfcloud/Aspose+Pdf+Exporter+for+Wordpress) for detailed manual

**Manual Installation**
1. Download the plugin and extract it.
2. Upload the directory '/aspose-pdf-exporter/' to the '/wp-content/plugins/' directory.
3. Activate the plugin through the 'Plugins' menu in WordPress.
4. Click on 'Aspose.PDF Exporter' link under Settings menu to access the admin section.
5. Click `Enable Free and Unlimited Access`. No Sign Up required.

== Screenshots ==

1. Plugin configuration/activation settings - "Easy one click setup"
2. Post Page with "Aspose.PDF Exporter" Option


== Plugin Requirements ==
- This Plugin works only with PHP version >=5.6.20

== Frequently Asked Questions ==

Do you have questions or issues with Aspose.PDF Exporter? Please Use these support channels.

1. [Docs](https://docs.aspose.cloud/display/pdfcloud/Plugins)
	- [FAQ](https://docs.aspose.cloud/display/pdfcloud/Aspose.PDF+Cloud+for+WordPress+-+FAQs)
	- [Aspose.PDF Exporter](https://docs.aspose.cloud/display/pdfcloud/Aspose+Pdf+Exporter+for+Wordpress)
1. [Support forum](https://forum.aspose.cloud/c/pdf)
1. [Blog](https://blog.aspose.cloud/)


== Changelog ==
= 3.2 =
* Fixed - Activator URL warning

= 3.1 =
* Fixed - "Sorry you are not allowed to access this page" issue

= 3.0 =
* Easy one click setup.
* Free and unlimited Access to Export your WordPress posts/pages to PDF.
* Automatic and secure self-configuration. No need to Sign In or Sign Up on [aspose.cloud](https://www.aspose.cloud/) website.
* Upgraded to latest Aspose.Cloud REST API.
* Upgraded to latest Aspose.PDF Cloud SDK.

= 2.0 =
* As soon posts/pages are exported into PDF, it will prompt to save PDF file instead of link for download file.

= 1.0 =
* This is the first version
