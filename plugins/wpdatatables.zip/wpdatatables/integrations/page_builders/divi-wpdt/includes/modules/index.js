import WpDataTable from './WpDataTable/WpDataTable';
import WpDataChart from "./WpDataChart/WpDataChart";

export default [WpDataTable, WpDataChart];
