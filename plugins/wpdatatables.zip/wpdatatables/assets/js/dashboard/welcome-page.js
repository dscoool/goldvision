jQuery('.carousel').carousel({
    interval: 3000
})