<?php
namespace Wpbi\Settings;

use Wpbi\Settings;

class WpOptions {

}
