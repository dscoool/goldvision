<?php $this->layout('admin/baseLayout',
  array('title' => 'Charts', 'titleAction' => $showCreateUrl ))
?>
<?=$table?>
