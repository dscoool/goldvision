<?php $this->layout('admin/baseLayout',
  array('title' => 'Queries', 'titleAction' => $showCreateUrl ))
?>
<?=$table?>
