<?php $this->layout('admin/baseLayout',
  array('title' => 'Data Tables', 'titleAction' => $showCreateUrl ))
?>
<?=$table?>
