<?php $this->layout('admin/baseLayout',
  array('title' => 'Connections', 'titleAction' => $showCreateUrl))
?>
<?=$table?>
