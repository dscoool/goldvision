<?php $this->layout('admin/baseLayout',
  array('title' => 'WordPress Data Connections', 'titleAction' => $showCreateUrl))
?>
<?=$table?>
