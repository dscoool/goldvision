<?php $this->layout('admin/baseLayout', array('title' => 'Variables'))?>
<?php // TODO: show upgrade information for lite users ?>
<p>Feature available in Pro version</p>
