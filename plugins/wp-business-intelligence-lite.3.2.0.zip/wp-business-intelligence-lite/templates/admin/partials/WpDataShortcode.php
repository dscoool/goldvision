<h2>Shortcode</h2>
<p>Copy the following into a post to display this embed.</p>
<textarea rows="1" class="large-text readonly" readonly="readonly">
  [wpbi_wp_data id="<?=$this->e($wpDataId)?>" /]
</textarea>
