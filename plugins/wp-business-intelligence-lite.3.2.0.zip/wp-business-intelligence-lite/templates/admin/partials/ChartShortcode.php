<h2>Shortcode</h2>
<p>Copy the following into a post to display this chart.</p>
<textarea rows="1" class="large-text readonly" readonly="readonly">
  [wpbi_chart type="<?=$this->e($chartType)?>" id="<?=$this->e($chartId)?>" /]
</textarea>