<?php

namespace Wpbi\Admin\Menu\Britechart;

use Wpbi\Admin\Menu\AbstractChart;

// TODO: uncovered
class GroupedBarChart extends AbstractChart {

  protected static function checkboxFields() {
    return array('show_legend');
  }

}
