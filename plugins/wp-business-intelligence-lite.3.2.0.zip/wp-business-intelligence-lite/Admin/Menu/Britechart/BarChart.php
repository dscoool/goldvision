<?php

namespace Wpbi\Admin\Menu\Britechart;

use Wpbi\Admin\Menu\AbstractChart;

// TODO: uncovered
class BarChart extends AbstractChart {

}
